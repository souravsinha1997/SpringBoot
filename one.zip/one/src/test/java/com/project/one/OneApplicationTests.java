package com.project.one;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OneApplicationTests {

	@Test
	void contextLoads() {
	}

}
