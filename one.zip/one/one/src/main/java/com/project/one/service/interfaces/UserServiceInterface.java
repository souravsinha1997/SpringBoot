package com.project.one.service.interfaces;

import com.project.one.entity.Request;
import com.project.one.entity.Token;

public interface UserServiceInterface {

    Token signUp(Request request);
    Token signIn(Request request);
}
