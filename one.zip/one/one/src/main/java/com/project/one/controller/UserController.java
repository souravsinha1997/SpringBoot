package com.project.one.controller;

import com.project.one.entity.Request;
import com.project.one.entity.Role;
import com.project.one.entity.Token;
import com.project.one.entity.User;
import com.project.one.service.UserService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping("/signUp")
    public ResponseEntity<Map<String, String>> signUp(
            @Valid @RequestBody Request request
    ) {

        request.setRole(Role.USER);
        userService.signUp(request);
        Map<String, String> response = new HashMap<>();
        response.put("message","User registered successfully");
        return ResponseEntity.ok(response);

    }

    @PostMapping("/signIn")
    public ResponseEntity<Token> signIn(
            @RequestBody Request request
    ) {

        return ResponseEntity.ok(userService.signIn(request));
    }
}
