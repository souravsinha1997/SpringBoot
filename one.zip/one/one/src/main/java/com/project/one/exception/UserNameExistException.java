package com.project.one.exception;

public class UserNameExistException extends RuntimeException {

    public UserNameExistException(String s) {
        super(s);
    }
}
