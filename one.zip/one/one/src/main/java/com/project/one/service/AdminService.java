package com.project.one.service;

import com.project.one.entity.Request;
import com.project.one.entity.Response;
import com.project.one.entity.User;
import com.project.one.entity.mapper.RequestToUser;
import com.project.one.entity.mapper.UserToResponse;
import com.project.one.exception.UserNotFoundException;
import com.project.one.repository.UserRepository;
import com.project.one.service.interfaces.AdminServiceInterface;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class AdminService implements AdminServiceInterface {

    private final UserRepository userRepo;
    //private final PasswordEncoder encoder;

    AdminService(UserRepository userRepo){
        this.userRepo = userRepo;
        //this.encoder = encoder;
    }

    public List<Response> getAllUsers(){
        List<User> users =  userRepo.findAll();
        return users.stream().map(UserToResponse::getResponseMapper).toList();
    }

    public Response getUserById(int id){
        User user = userRepo.findById(id).orElse(null);
        if(user != null) {
            return UserToResponse.getResponseMapper(user);
        }
        else{
            throw new UserNotFoundException("User not found with id : "+id);
        }
    }

    public Response getUserByName(String name){
        User user = userRepo.findByUserName(name).orElse(null);
        if(user !=null){
            return UserToResponse.getResponseMapper(user);
        }
        else{
            throw new UserNotFoundException("User does not exist with username : "+name);
        }
    }

//    public String saveUser(Request req){
//        User user = RequestToUser.getUserMapper(req);
//
//        User savedUser = userRepo.findByUserName(req.getUserName()).orElse(null);
//        if(savedUser == null){
//            user.setPassword(encoder.encode(user.getPassword()));
//            userRepo.save(user);
//            return "User registered successfully!";
//        }
//        else{
//            throw new RuntimeException("User already exist with same username :"+req.getUserName());
//        }
//    }

    public String deleteUser(int id){
        User user = userRepo.findById(id).orElse(null);
        if(user != null){
            userRepo.delete(user);
            return "User deleted successfully";
        }
        else{
            throw new UserNotFoundException("User not found with id : "+id);
        }
    }
}
