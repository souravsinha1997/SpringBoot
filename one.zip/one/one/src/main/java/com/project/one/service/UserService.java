package com.project.one.service;

import com.project.one.entity.Request;
import com.project.one.entity.Role;
import com.project.one.entity.Token;
import com.project.one.entity.User;
import com.project.one.exception.UserNameExistException;
import com.project.one.exception.UserNotFoundException;
import com.project.one.repository.UserRepository;
import com.project.one.service.interfaces.UserServiceInterface;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserService implements UserServiceInterface {

    private final UserRepository userRepo;
    private final PasswordEncoder encoder;
    private final JwtService jwtService;
    private final AuthenticationManager authManager;

    UserService(UserRepository userRepo,PasswordEncoder encoder,JwtService jwtService,AuthenticationManager authManager){
        this.userRepo = userRepo;
        this.encoder = encoder;
        this.jwtService = jwtService;
        this.authManager = authManager;
    }

    public Token signUp(Request req){
        User savedUser = userRepo.findByUserName(req.getUserName()).orElse(null);
        if(savedUser != null){
            throw new UserNameExistException("User name already exist : "+req.getUserName());
        }
        User user = new User();
        user.setUserName(req.getUserName());
        user.setPassword(encoder.encode(req.getPassword()));
        if(req.getRole()!=null)
            user.setRole(req.getRole());
        else
            user.setRole(Role.USER);
        user = userRepo.save(user);

        String token = jwtService.generateToken(user);
        return new Token(token);
    }

    public Token signIn(Request req){
        authManager.authenticate(new UsernamePasswordAuthenticationToken(req.getUserName(),req.getPassword()));

        User user = userRepo.findByUserName(req.getUserName()).orElse(null);
        if(user == null){
            throw new UserNotFoundException("User not found with user name : "+req.getUserName());
        }

        String token = jwtService.generateToken(user);
        return new Token(token);
    }

}
