package com.project.one.entity.mapper;

import com.project.one.entity.Response;
import com.project.one.entity.User;

public class UserToResponse {

    public static Response getResponseMapper(User user){
        Response res = new Response();

        res.setId(user.getId());
        res.setUserName(user.getUserName());
        res.setRole(user.getRole().toString());

        return res;
    }
}
