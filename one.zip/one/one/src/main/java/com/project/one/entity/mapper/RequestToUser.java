package com.project.one.entity.mapper;

import com.project.one.entity.Request;
import com.project.one.entity.User;

public class RequestToUser {

    public static User getUserMapper(Request req){
        User user = new User();

        user.setId(req.getId());
        user.setUserName(req.getUserName());
        user.setPassword(req.getPassword());
        user.setRole(req.getRole());

        return user;
    }

}
