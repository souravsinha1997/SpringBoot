package com.project.one.controller;

import com.project.one.entity.Request;
import com.project.one.entity.Response;
import com.project.one.service.AdminService;
import com.project.one.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class AdminController {

    private final AdminService adminService;
    private final UserService userService;

    public AdminController(AdminService adminService,UserService userService) {
        this.adminService = adminService;
        this.userService = userService;
    }

    @GetMapping("/users/{id}")
    @PreAuthorize("hasAnyAuthority('USER', 'ADMIN')")
    public ResponseEntity<Response> getUserById(@PathVariable Integer id) {
        return ResponseEntity.ok(adminService.getUserById(id));
    }

    @GetMapping("/admin/all")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<List<Response>> getAllUsers() {
        return ResponseEntity.ok(adminService.getAllUsers());
    }

    @PostMapping("/admin/create-user")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<Map<String, String>> createUser(@RequestBody Request user) {
        userService.signUp(user);
        Map<String, String> response = new HashMap<>();
        response.put("message","User registered successfully");
        return ResponseEntity.ok(response);
    }

    @DeleteMapping("/admin/{id}")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<Map<String, String>> deleteUser(@PathVariable Integer id) {
        adminService.deleteUser(id);
        Map<String, String> response = new HashMap<>();
        response.put("message","User deleted successfully");
        return ResponseEntity.ok(response);
    }


}
