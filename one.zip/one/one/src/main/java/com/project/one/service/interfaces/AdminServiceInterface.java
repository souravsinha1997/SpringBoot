package com.project.one.service.interfaces;

import com.project.one.entity.Request;
import com.project.one.entity.Response;

import java.util.List;

public interface AdminServiceInterface {

    List<Response> getAllUsers();

    Response getUserById(int id);

    Response getUserByName(String name);

    //String saveUser(Request req);

    String deleteUser(int id);
}
