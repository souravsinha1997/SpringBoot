package com.project.one.entity;

public enum Role {
    USER,
    ADMIN
}
